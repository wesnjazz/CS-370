import numpy as np
import time

# This code is part of:
#
#   CMPSCI 370: Computer Vision, Spring 2018
#   University of Massachusetts, Amherst
#   Instructor: Subhransu Maji
#
#   Homework 4

def ransac(matches, c1, c2):
    raise NotImplementedError

