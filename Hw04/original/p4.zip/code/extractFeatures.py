import numpy as np
from skimage.color import rgb2gray

#This code is part of:
#
#  CMPSCI 370: Computer Vision, Spring 2018
#  University of Massachusetts, Amherst
#  Instructor: Subhransu Maji
#
#  Homework 4

def extractFeatures(im, c, patch_radius):
    raise NotImplementedError
