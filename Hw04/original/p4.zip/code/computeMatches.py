import numpy as np

# This code is part of:
#
#   CMPSCI 370: Computer Vision, Spring 2018
#   University of Massachusetts, Amherst
#   Instructor: Subhransu Maji
#
#   Homework 4

def computeMatches(f1, f2):
    raise NotImplementedError

