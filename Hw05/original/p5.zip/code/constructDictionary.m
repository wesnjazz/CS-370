function C = constructDictionary(x, K, ps)
% x: [h, w, 1, n]

C = zeros(ps, ps, K);