function score = scoreFeatures(x, y)

score = zeros(size(x, 1), size(x, 2));
