def scoreFeatrues(x, y):
    return np.zeros(x.shape[:2])
