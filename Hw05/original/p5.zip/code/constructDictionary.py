import numpy as np
from sklearn.cluster import KMeans

def constructDictionary(x, K, ps):
    C = np.zeros(ps, ps, K)

    return C
