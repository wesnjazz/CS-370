function y = encodeImage(im, C)

y = ones(size(C, 3), 1);