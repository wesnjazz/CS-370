import numpy as np
from scipy.spatial.distance import cdist

def encodeImage(im, C):
    
	y = np.ones([C.shape[2], 1])
    return y
