function [im, predShift] = alignChannels(im, maxShift)
% Implement this
im = im;
predShift = zeros(2,2);