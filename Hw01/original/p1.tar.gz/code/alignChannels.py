# This code is part of:
#
#   CMPSCI 370: Computer Vision, Spring 2018
#   University of Massachusetts, Amherst
#   Instructor: Subhransu Maji
#
#   Homework 1 

import numpy as np

def alignChannels(img, max_shift):
    # raise NotImplementedError("You should implement this.")
    return(img, np.zeros((2, 2)))

